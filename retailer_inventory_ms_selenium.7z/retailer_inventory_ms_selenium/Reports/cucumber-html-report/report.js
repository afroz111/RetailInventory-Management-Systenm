$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/resources/features/TestCase.feature");
formatter.feature({
  "name": ":To Test The RetailerInventory-Ms Application",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "To Add Retails In RetailerInventory-MS",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "To launch the browser and Navigate to the Url",
  "keyword": "Given "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.to_launch_the_browser_and_Navigate_to_the_Url()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Open  Add Retailers functionality of RetailerInventory-Ms",
  "keyword": "When "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.to_Open_Add_Retailers_functionality_of_RetailerInventory_Ms()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Enter RetailerID",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.to_Enter_RetailerID()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Enter ProductCategory",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.to_Enter_ProductCategory()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Enter ProductId",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.to_Enter_ProductId()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Enter ProductUniqueId",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.to_Enter_ProductUniqueId()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Enter ProductDispatchTimestamp",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.to_Enter_ProductDispatchTimestamp()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ProductReceiveTimestamp",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.productreceivetimestamp()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ProductSaleTimestamp",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.productsaletimestamp()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click Register Button",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.click_Register_Button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Take the Screenshot and the Title",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInvnetoryAddStep.take_the_Screenshot_and_the_Title()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "To view In RetailerInventory_MS",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "Click On View",
  "keyword": "Given "
});
formatter.match({
  "location": "com.step_defination.RetailerInventoryViewStep.click_On_View()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Take the Screenshot And Tile",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventoryViewStep.take_the_Screenshot_And_Tile()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "To Update In RetailerInventory-Ms",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "Click to UpdateReceiveTime",
  "keyword": "Given "
});
formatter.match({
  "location": "com.step_defination.RetailerInventoryUpdateRecTimeStep.click_to_UpdateReceiveTime()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Enter RetailerId",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventoryUpdateRecTimeStep.to_Enter_RetailerId()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Enter ProductReceiveTimeStamp",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventoryUpdateRecTimeStep.to_Enter_ProductReceiveTimeStamp()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click Update Button",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventoryUpdateRecTimeStep.click_Update_Button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Take ScreenShot and the Title",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventoryUpdateRecTimeStep.take_ScreenShot_and_the_Title()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "To Update In RetailerInventory-Ms",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "Click to UpdateSaleTime",
  "keyword": "Given "
});
formatter.match({
  "location": "com.step_defination.RetailerInventorySaleTimeStep.click_to_UpdateSaleTime()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Enter SRetailerId",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventorySaleTimeStep.to_Enter_SRetailerId()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "To Enter ProductSaleTimeStamp",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventorySaleTimeStep.to_Enter_ProductSaleTimeStamp()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click SaleUpdate Button",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventorySaleTimeStep.click_SaleUpdate_Button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Take SnapShot and the Title",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventorySaleTimeStep.take_SnapShot_and_the_Title()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the Browserr",
  "keyword": "Then "
});
formatter.match({
  "location": "com.step_defination.RetailerInventorySaleTimeStep.close_the_Browserr()"
});
formatter.result({
  "status": "passed"
});
});