package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.base_class.Library;

public class RetailerInventoryUpdateRecTimePage extends Library {
	Select select;
	public RetailerInventoryUpdateRecTimePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "/html/body/app-root/header/app-header/header/nav[2]/ul/div[3]/li/button")
	WebElement menu_UpdateButton;
	@FindBy(id = "retailerId")
	WebElement AddRetailerId;
	@FindBy(id = "productReceiveTimestamp")
	WebElement UpdateRec;

	@FindBy(xpath = "/html/body/app-root/body/app-update-receive-time-stamp/div/form/button")
	WebElement update;
	
	
	
	public void update() {
		menu_UpdateButton.click();
		
	}
	
	public void retailerId(String retailerId) {
		AddRetailerId.sendKeys(retailerId);
	
	}
	public void recTime(String productReceiveTimestamp) {
		UpdateRec.sendKeys(productReceiveTimestamp);
	
	}
	public void updateBtn() {
		update.click();
		
	}
	
}
