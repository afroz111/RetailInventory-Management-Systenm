package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.base_class.Library;

public class RetailerInventoryViewPage extends Library {
	Select select;
	public RetailerInventoryViewPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "/html/body/app-root/header/app-header/header/nav[2]/ul/div[2]/li/button")
	WebElement menu_ViewButton;
	
	
	public void view() {
		menu_ViewButton.click();
		
	}
}
