package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RetailerInventrorySearchPage {
	Select select;
	public RetailerInventrorySearchPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "/html/body/app-root/header/app-header/header/nav[2]/ul/div[5]/li/button")
	WebElement menu_SearchButton;
	@FindBy(id = "retailerId")
	WebElement AddRetailerId;
	
	
	@FindBy(xpath = "/html/body/app-root/body/app-search/form/button")
	WebElement SearchButton;
	
	public void search() {
		menu_SearchButton.click();
		
	}
	public void retId(String retailerId) {
		AddRetailerId.sendKeys(retailerId);
		
	}
	public void searchBtn() {
		menu_SearchButton.click();
		
	}
}
