package com.pages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.base_class.Library;

public class RetailerInventoryAddPage  extends Library{
	Select select;
	 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	  LocalDate localDate = LocalDate.now();
	public RetailerInventoryAddPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "/html/body/app-root/header/app-header/header/nav[2]/ul/div[1]/li/button")
	WebElement menu_AddButton;
	@FindBy(id = "retailerId")
	WebElement AddRetailerId;
	@FindBy(id = "productCategory")
	WebElement AddProductCategory;
	
	@FindBy(id = "productId")
	WebElement AddProductId; 
	
	@FindBy(id = "productUniqueId")
	WebElement AddPproductUniqueId;
	
	@FindBy(xpath="/html/body/app-root/body/app-add-retailers/div/form/div[5]/input")
	WebElement AddProductDispatchTimestamp;
	
	@FindBy(id = "productReceiveTimestamp")
	WebElement AddProductReceiveTimestamp;
	
	@FindBy(id = "productSaleTimestamp")
	WebElement AddProductSaleTimestamp;

	@FindBy(xpath = "/html/body/app-root/body/app-add-retailers/div/form/button")
	WebElement menu_RegButton;
	
	
	
	
//	Alert alert= driver.switchTo().alert();
	public void addRetailerDB() {
		menu_AddButton.click();
		
	}
	
	public void retailerId(String retailerId) {
		AddRetailerId.sendKeys(retailerId);
	
	}
	
	public void prdCatg(String prodCatg) {
		AddProductCategory.sendKeys(prodCatg);
	}
	
	public void prdId(String PrdId) {
		AddProductId.sendKeys(PrdId);
	}
	
	public void prdUnqId(String UnqId) {
		AddPproductUniqueId.sendKeys(UnqId);
	}
	
	public void prdDisp(String dispTime) {
		AddProductDispatchTimestamp.sendKeys(dispTime);
	}
	
	public void prdRec(String recvTime) {
		AddProductReceiveTimestamp.sendKeys(recvTime);
	}
	
	public void prdSale(String saleTime) {
		AddProductSaleTimestamp.sendKeys(saleTime);
	}
	
	public void reg() {
	menu_RegButton.click();
	}
}
