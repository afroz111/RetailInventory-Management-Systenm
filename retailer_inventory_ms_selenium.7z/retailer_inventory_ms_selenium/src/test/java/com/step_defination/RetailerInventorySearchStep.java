package com.step_defination;

import com.base_class.Library;
import com.pages.RetailerInventoryUpdateSalePage;
import com.pages.RetailerInventrorySearchPage;
import com.selenium_reuseabilityfunction.SeleniumUtility;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class RetailerInventorySearchStep extends Library {

	RetailerInventrorySearchPage retailerPage;
	SeleniumUtility seleniumUtility;
	
	

@Given("Click to Search")
public void click_to_Search() {
	RetailerInventrorySearchPage retailerPage =new RetailerInventrorySearchPage(driver);
	retailerPage.search();
	logger.info("menu Search button is clicked");
}

@Then("To Enter SSRetailerId")
public void to_Enter_SSRetailerId() {
	RetailerInventrorySearchPage retailerPage =new RetailerInventrorySearchPage(driver);
	retailerPage.retId(properties.getProperty("retailerId"));
	logger.info("menu Search button is clicked");
}

@Then("Click Find Button")
public void click_Find_Button() {
	RetailerInventrorySearchPage retailerPage =new RetailerInventrorySearchPage(driver);
	retailerPage.searchBtn();
	org.openqa.selenium.support.ui.WebDriverWait wait = new org.openqa.selenium.support.ui.WebDriverWait(driver, 10);
	logger.info("menu Search button is clicked");
}

@Then("Take SnapShot And Titlebar")
public void take_SnapShot_And_Titlebar() {
	seleniumUtility = new SeleniumUtility(driver);
	seleniumUtility.to_take_screenshot("searchAdmin");
	seleniumUtility.getTitle();
	 logger.info("menu Update is clicked");
}

@Then("Terminate")
public void terminate() {
	tearDown();
	logger.info("Browser is Closed"); 
}



}
