package com.step_defination;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.base_class.Library;
import com.pages.RetailerInventoryUpdateSalePage;
import com.selenium_reuseabilityfunction.SeleniumUtility;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class RetailerInventorySaleTimeStep extends Library{

	RetailerInventoryUpdateSalePage retailerPage;
	SeleniumUtility seleniumUtility;
	
	
	@Given("Click to UpdateSaleTime")
	public void click_to_UpdateSaleTime() {
		RetailerInventoryUpdateSalePage retailerPage=new RetailerInventoryUpdateSalePage(driver);
		retailerPage.update();
		logger.info("menu Update  button is clicked");
	}
	
	@Then("To Enter SRetailerId")
	public void to_Enter_SRetailerId() {
		RetailerInventoryUpdateSalePage retailerPage = new RetailerInventoryUpdateSalePage(driver);
		   retailerPage.retailerId(properties.getProperty("retailerId"));
		   logger.info("menu Update  button is clicked");
	}


	@Then("To Enter ProductSaleTimeStamp")
	public void to_Enter_ProductSaleTimeStamp() {
		RetailerInventoryUpdateSalePage retailerPage=new RetailerInventoryUpdateSalePage(driver);
		retailerPage.recTime(properties.getProperty("productSaleTimeStamp"));
		logger.info("menu Update  button is clicked");
	}

	@Then("Click SaleUpdate Button")
	public void click_SaleUpdate_Button() {
		RetailerInventoryUpdateSalePage retailerPage=new RetailerInventoryUpdateSalePage(driver);
		retailerPage.updateBtn();
		logger.info("menu Update  button is clicked");
	}

	@Then("Take SnapShot and the Title")
	public void take_SnapShot_and_the_Title() {
		seleniumUtility = new SeleniumUtility(driver);
		seleniumUtility.to_take_screenshot("searchAdmin");
		seleniumUtility.getTitle();
		  
		   org.openqa.selenium.support.ui.WebDriverWait wait = new org.openqa.selenium.support.ui.WebDriverWait(driver, 10);	 
		   wait.until(ExpectedConditions.alertIsPresent());	
			Alert alert=driver.switchTo().alert();	 
			String msg=driver.switchTo().alert().getText();	 
			alert.accept();	 
			logger.info(msg);
		   logger.info("menu Update is clicked");
	}

//	@Then("close the Browserr")
//	public void close_the_Browserr() {
//		tearDown();
//		logger.info("Browser is Closed"); 
//	}



}
