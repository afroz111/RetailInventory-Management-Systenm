package com.step_defination;

import com.base_class.Library;
import com.pages.RetailerInventoryViewPage;
import com.selenium_reuseabilityfunction.SeleniumUtility;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class RetailerInventoryViewStep extends Library {
	RetailerInventoryViewPage retailerPage;
	SeleniumUtility seleniumUtility;
	
	@Given("Click On View")
	public void click_On_View() {
		RetailerInventoryViewPage retailerPage = new RetailerInventoryViewPage(driver);
		retailerPage.view();
		   logger.info("menu Add Retailer  button is clicked");
	}

	@Then("Take the Screenshot And Tile")
	public void take_the_Screenshot_And_Tile() {
		seleniumUtility = new SeleniumUtility(driver);
		seleniumUtility.to_take_screenshot("searchAdmin");
		seleniumUtility.getTitle();
		logger.info("Taken Screenshot Of Reg And Title printed in console");
	}
	
	
	
}
