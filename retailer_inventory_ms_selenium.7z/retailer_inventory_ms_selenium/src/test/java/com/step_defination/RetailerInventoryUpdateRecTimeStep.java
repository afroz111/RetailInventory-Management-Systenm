package com.step_defination;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.base_class.Library;
import com.pages.RetailerInventoryUpdateRecTimePage;
import com.selenium_reuseabilityfunction.SeleniumUtility;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class RetailerInventoryUpdateRecTimeStep extends Library {

	RetailerInventoryUpdateRecTimePage retailerPage;
	SeleniumUtility seleniumUtility;
	
	
//	
//	@Given("Click to UpdateReceiveTime")
//	public void click_to_UpdateReceiveTime() {
//		RetailerInventoryUpdateRecTimePage retailerPage = new RetailerInventoryUpdateRecTimePage(driver);
//		   retailerPage.update();
//		   logger.info("menu Update  button is clicked");
//	}
//
//	@Then("To Enter RetailerId")
//	public void to_Enter_RetailerId() {
//		RetailerInventoryUpdateRecTimePage retailerPage = new RetailerInventoryUpdateRecTimePage(driver);
//		   retailerPage.retailerId(properties.getProperty("retailerId"));
//		   logger.info("menu Update  button is clicked");
//	}
//
//	@Then("To Enter ProductReceiveTimeStamp")
//	public void to_Enter_ProductReceiveTimeStamp() {
//		RetailerInventoryUpdateRecTimePage retailerPage = new RetailerInventoryUpdateRecTimePage(driver);
//		   retailerPage.recTime(properties.getProperty("productReceiveTimestamp"));
//		   logger.info("menu Update  button is clicked");
//	}
//
//	@Then("Click Update Button")
//	public void click_Update_Button() {
//		RetailerInventoryUpdateRecTimePage retailerPage = new RetailerInventoryUpdateRecTimePage(driver);
//		   retailerPage.updateBtn();
//		   logger.info("menu Update  button is clicked");
//	}
//
//	@Then("Take ScreenShot and the Title")
//	public void take_ScreenShot_and_the_Title() {
//		seleniumUtility = new SeleniumUtility(driver);
//		seleniumUtility.to_take_screenshot("searchAdmin");
//		seleniumUtility.getTitle();
//		logger.info("Taken Screenshot Of Reg And Title printed in console");
//	}
//
//
	@Given("Click to UpdateReceiveTime")
	public void click_to_UpdateReceiveTime() {
		RetailerInventoryUpdateRecTimePage retailerPage = new RetailerInventoryUpdateRecTimePage(driver);
	   retailerPage.update();
	   logger.info("menu Update  button is clicked");
	}

	@Then("To Enter RetailerId")
	public void to_Enter_RetailerId() {
		RetailerInventoryUpdateRecTimePage retailerPage = new RetailerInventoryUpdateRecTimePage(driver);
		   retailerPage.retailerId(properties.getProperty("retailerId"));
		   logger.info("menu Update  button is clicked");
	}

	@Then("To Enter ProductReceiveTimeStamp")
	public void to_Enter_ProductReceiveTimeStamp() {
		RetailerInventoryUpdateRecTimePage retailerPage = new RetailerInventoryUpdateRecTimePage(driver);
		   retailerPage.recTime(properties.getProperty("productReceiveTimeStamp"));
		   logger.info("menu Update  button is clicked");
	}

	@Then("Click Update Button")
	public void click_Update_Button() {
		RetailerInventoryUpdateRecTimePage retailerPage = new RetailerInventoryUpdateRecTimePage(driver);
		   retailerPage.updateBtn();
		   org.openqa.selenium.support.ui.WebDriverWait wait = new org.openqa.selenium.support.ui.WebDriverWait(driver, 10);	 
		   wait.until(ExpectedConditions.alertIsPresent());	
			Alert alert=driver.switchTo().alert();	 
			String msg=driver.switchTo().alert().getText();	 
			alert.accept();	 
			logger.info(msg);
		   logger.info("menu Update  button is clicked");
	}

	@Then("Take ScreenShot and the Title")
	public void take_ScreenShot_and_the_Title() {
		seleniumUtility = new SeleniumUtility(driver);
		seleniumUtility.to_take_screenshot("searchAdmin");
		seleniumUtility.getTitle();
		  
		   
		   logger.info("menu Update is clicked");
		   
	}
//	@Then("close the Browser")
//	public void close_the_Browser() {
//		tearDown();
//		logger.info("Browser is Closed"); 
//		}


}
