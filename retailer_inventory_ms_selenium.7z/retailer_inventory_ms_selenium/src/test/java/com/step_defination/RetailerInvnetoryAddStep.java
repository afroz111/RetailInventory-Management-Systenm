package com.step_defination;

import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.base_class.Library;
import com.pages.RetailerInventoryAddPage;
import com.selenium_reuseabilityfunction.SeleniumUtility;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RetailerInvnetoryAddStep extends Library {
	RetailerInventoryAddPage retailerPage;
	SeleniumUtility seleniumUtility;
	
	@Given("To launch the browser and Navigate to the Url")
	public void to_launch_the_browser_and_Navigate_to_the_Url() {
		 browserSetUp();
		    logger.info("Browser Launched");
	}
	@When("To Open  Add Retailers functionality of RetailerInventory-Ms")
	public void to_Open_Add_Retailers_functionality_of_RetailerInventory_Ms() {
		RetailerInventoryAddPage retailerPage = new RetailerInventoryAddPage(driver);
		   retailerPage.addRetailerDB();
		   logger.info("menu Add Retailer  button is clicked");
	}
	
	@Then("To Enter RetailerID")
	public void to_Enter_RetailerID() {

		RetailerInventoryAddPage retailerPage = new RetailerInventoryAddPage(driver);
		   retailerPage.retailerId(properties.getProperty("productId"));
		   logger.info("menu Add Retailer  button is clicked");
	}

	@Then("To Enter ProductCategory")
	public void to_Enter_ProductCategory() {
	  	RetailerInventoryAddPage retailerPage = new RetailerInventoryAddPage(driver);
		   retailerPage.prdCatg(properties.getProperty("productCategory"));
		   logger.info("menu Add Retailer  button is clicked");
	}

	@Then("To Enter ProductId")
	public void to_Enter_ProductId() {
	
		RetailerInventoryAddPage retailerPage = new RetailerInventoryAddPage(driver);
		   retailerPage.prdId(properties.getProperty("productId"));
		   logger.info("menu Add Retailer  button is clicked");
	}
	@Then("To Enter ProductUniqueId")
	public void to_Enter_ProductUniqueId() {
	    
		RetailerInventoryAddPage retailerPage = new RetailerInventoryAddPage(driver);
		   retailerPage.prdUnqId(properties.getProperty("productUniqueId"));
		   logger.info("menu Add Retailer  button is clicked");
	}

	@Then("To Enter ProductDispatchTimestamp")
	public void to_Enter_ProductDispatchTimestamp() {
	   
		RetailerInventoryAddPage retailerPage = new RetailerInventoryAddPage(driver);
		   retailerPage.prdDisp(properties.getProperty("productDispatchTimeStamp"));
		   logger.info("menu Add Retailer  button is clicked");
	}

	@Then("ProductReceiveTimestamp")
	public void productreceivetimestamp() {
	 
		RetailerInventoryAddPage retailerPage = new RetailerInventoryAddPage(driver);
		   retailerPage.prdRec(properties.getProperty("productReceiveTimeStamp"));
		   logger.info("menu Add Retailer  button is clicked");
	}

	@Then("ProductSaleTimestamp")
	public void productsaletimestamp() {
	   
		RetailerInventoryAddPage retailerPage = new RetailerInventoryAddPage(driver);
		   retailerPage.prdSale(properties.getProperty("productsaleTimeStamp"));
		   logger.info("menu Add Retailer  button is clicked");
	}



	@Then("Click Register Button")
	public void click_Register_Button() {
	  
		RetailerInventoryAddPage retailerPage = new RetailerInventoryAddPage(driver);
		   retailerPage.reg();
		   
		   org.openqa.selenium.support.ui.WebDriverWait wait = new org.openqa.selenium.support.ui.WebDriverWait(driver, 10);	 
		   wait.until(ExpectedConditions.alertIsPresent());	
			Alert alert=driver.switchTo().alert();	 
			String msg=driver.switchTo().alert().getText();	 
			alert.accept();	 
			logger.info(msg);
		   logger.info("menu Reg  button is clicked");
		   
	}

	@Then("Take the Screenshot and the Title")
	public void take_the_Screenshot_and_the_Title() {
		seleniumUtility = new SeleniumUtility(driver);
		seleniumUtility.to_take_screenshot("searchAdmin");
		seleniumUtility.getTitle();
		logger.info("Taken Screenshot Of Reg And Title printed in console");
		
	}

	
}