//package com.testcases;
//
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
//
//import org.junit.Test;
//import org.testng.annotations.AfterTest;
//import org.testng.annotations.BeforeTest;
//
//import com.base_class.Library;
//import com.pages.RetailerInventoryAddPage;
//import com.selenium_reuseabilityfunction.SeleniumUtility;
//
//public class RetailerInventoryTestCase extends Library {
//	RetailerInventoryAddPage lpage;
//	SeleniumUtility seleniumUtil;
//	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//	  LocalDate localDate = LocalDate.now();
//	
//	@BeforeTest
//	public void launchApp()
//	{
//		browserSetUp();
//		logger.info("browser launch");
//	}
//	
//	
//
//	@Test
//	public void addRetailer() {
//		lpage=new RetailerInventoryAddPage(driver);
//		lpage.retailerId(properties.getProperty("retailerId"));
//		lpage.prdCatg(properties.getProperty("prodCatg"));
//		lpage.prdId(properties.getProperty("PrdId"));
//		lpage.prdDisp(properties.getProperty("dispTime"));
//		lpage.prdUnqId(properties.getProperty("UnqId")); 
//		lpage.prdRec(properties.getProperty("recvTime"));
//		lpage.prdSale(properties.getProperty("saleTime"));
//	
//		logger.info("Added Sucessfully");
//	}
////	@Test
////	public void addCat() {
////		lpage=new RetailerInventoryAddPage(driver);
////		lpage.prdCatg(properties.getProperty("prodCatg"));
////	
////	
////		logger.info("Added Sucessfully");
////	}
////	@Test
////	public void addprId() {
////		lpage=new RetailerInventoryAddPage(driver);
////		lpage.prdId(properties.getProperty("PrdId"));  
////	
////	
////		logger.info("Added Sucessfully");
////	}
////	@Test
////	public void addUnq() {
////		lpage=new RetailerInventoryAddPage(driver);
////		lpage.prdDisp(properties.getProperty("dispTime"));
////	
////	
////		logger.info("Added Sucessfully");
////	}
////	@Test
////	public void addDis() {
////		lpage=new RetailerInventoryAddPage(driver);
////		lpage.prdUnqId(properties.getProperty("UnqId")); 
////
////
////		logger.info("Added Sucessfully");
////	}
////	@Test
////	public void addRec() {
////		lpage=new RetailerInventoryAddPage(driver);
////		lpage.prdRec(properties.getProperty("recvTime"));
////		lpage.prdSale(properties.getProperty("saleTime"));
////	
////		logger.info("Added Sucessfully");
////	}
////	@Test
////	public void addSal() {
////		lpage=new RetailerInventoryAddPage(driver);
////		lpage.prdSale(properties.getProperty("saleTime"));
////	
////	
////		logger.info("Added Sucessfully");
////	}
//
//
//	
//	
//	
//	@AfterTest
//	public void close() {
//		
//		seleniumUtil = new SeleniumUtility(driver);   
//		seleniumUtil.getTitle();
//		seleniumUtil.to_take_screenshot("Addretailer");
//		tearDown();
//		lpage=new RetailerInventoryAddPage(driver);
//		lpage.retailerId(properties.getProperty("retailerId"));
//		lpage.prdCatg(properties.getProperty("prodCatg"));
//		lpage.prdId(properties.getProperty("PrdId"));
//		lpage.prdDisp(properties.getProperty("dispTime"));
//		lpage.prdUnqId(properties.getProperty("UnqId")); 
//		lpage.prdRec(properties.getProperty("recvTime"));
//		lpage.prdSale(properties.getProperty("saleTime"));
//	
//					logger.info("Added Done");
//	}
//}
//
//
