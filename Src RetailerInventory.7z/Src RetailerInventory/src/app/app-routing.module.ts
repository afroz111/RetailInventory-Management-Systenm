import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddRetailersComponent } from './add-retailers/add-retailers.component';
import { ListRetailersComponent } from './list-retailers/list-retailers.component';
import { SearchComponent } from './search/search.component';
import { UpdateReceiveTimeStampComponent } from './update-receive-time-stamp/update-receive-time-stamp.component';
import { UpdateSaleTimeStampComponent } from './update-sale-time-stamp/update-sale-time-stamp.component';


const routes: Routes = [


  { path:'addretailers', component:AddRetailersComponent},
  { path:'list-retailers', component: ListRetailersComponent},
  { path:'update-receive-time-stamp', component: UpdateReceiveTimeStampComponent},
  {path:'user-update-sale-time-stamp',component: UpdateSaleTimeStampComponent},
  {path:'search',component: SearchComponent},




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
