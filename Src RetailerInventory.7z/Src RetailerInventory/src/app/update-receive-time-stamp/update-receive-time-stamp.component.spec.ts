import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateReceiveTimeStampComponent } from './update-receive-time-stamp.component';

describe('UpdateReceiveTimeStampComponent', () => {
  let component: UpdateReceiveTimeStampComponent;
  let fixture: ComponentFixture<UpdateReceiveTimeStampComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateReceiveTimeStampComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateReceiveTimeStampComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
