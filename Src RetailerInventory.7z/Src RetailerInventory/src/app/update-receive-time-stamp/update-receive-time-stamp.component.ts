import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientServiceService, Retailer } from '../services/http-client-service.service';

@Component({
  selector: 'app-update-receive-time-stamp',
  templateUrl: './update-receive-time-stamp.component.html',
  styleUrls: ['./update-receive-time-stamp.component.css']
})
export class UpdateReceiveTimeStampComponent implements OnInit {
  Date=new Date().toLocaleDateString
  
  retailer: Retailer =new Retailer("","","","",new(Date),new(Date),new(Date))
  constructor(
    private HttpClientService:HttpClientServiceService,private router:Router
  ) { }

  ngOnInit(): void {
  }
  updateRecvTime(): void {
    console.log(this.retailer.productReceiveTimestamp);
    this.HttpClientService.updateRecvTime(this.retailer)
        .subscribe( data => {
          alert("ReceiveTime  updated successfully.");
        });
        this.router.navigate(['/list-retailers']);
  };
}
