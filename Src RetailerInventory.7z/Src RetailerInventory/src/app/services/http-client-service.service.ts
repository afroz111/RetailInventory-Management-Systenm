import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

export class Retailer{
  UpdateReceiveTimeStampComponent(UpdateReceiveTimeStampComponent: any) {
    throw new Error('Method not implemented.');
  }
  json: any;
  header: any;
  static find: any;
  constructor(
    public retailerId:string,
    public productCategory:string,
    public productId:string,
    public productUniqueId:string,
    public productDispatchTimestamp:Date,
    public productReceiveTimestamp:Date,
    public productSaleTimestamp:Date,
  ) {}
}

@Injectable({
  providedIn: 'root'
})
export class HttpClientServiceService {
  httpClient: any;

  constructor(
    private httpService:HttpClient
  ) { }
  AddRetailer(retailer): Observable<Retailer> {

    return this.httpService.post<Retailer>("http://localhost:8100/RetailInventory/Add",retailer,);
  }
  public ViewAll() {
    console.log("test-call")
    return this.httpService.get<Retailer[]>("http://localhost:8100/RetailInventory/ViewAll",{responseType: 'json'});
  }
  public deleteRetailer(retailer) {
    return this.httpService.delete<Retailer>("http://localhost:8100/RetailInventory/Delete"+"/"+retailer.retailerId);
    
  }
  public updateRecvTime(retailer) {
    console.log(retailer);
    return this.httpService.put<Retailer>("http://localhost:8100/RetailInventory/updateReceiveTime", retailer);
  }

  public updateSaleTime(retailer) {
    console.log(retailer);
    return this.httpService.put<Retailer>("http://localhost:8100/RetailInventory/updateSaleTime", retailer);
  }
  findretailerById(retailerId : String) : Observable<Retailer>
  {
    console.log(" Id = "+retailerId);
    return this.httpService.get<Retailer>("http://localhost:8100/RetailInventory/getById/"+retailerId);

  }


}
