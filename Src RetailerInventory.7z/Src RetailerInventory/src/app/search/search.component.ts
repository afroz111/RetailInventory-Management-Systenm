import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientServiceService, Retailer } from '../services/http-client-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  Date=new Date().toLocaleDateString
  
  
  retailer: Retailer =new Retailer("","","","",new(Date),new(Date),new(Date))
retailerId:String;
  constructor(
    private HttpClientService:HttpClientServiceService,private router:Router
  ) { }

  ngOnInit(): void {
  }
  findretailerById(){
this.HttpClientService.findretailerById(this.retailerId).subscribe(
  data=>{this.retailer=data

  }
);
}
}