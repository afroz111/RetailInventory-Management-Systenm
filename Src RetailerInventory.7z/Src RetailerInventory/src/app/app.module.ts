import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddRetailersComponent } from './add-retailers/add-retailers.component';
import { ListRetailersComponent } from './list-retailers/list-retailers.component';
import { UpdateReceiveTimeStampComponent } from './update-receive-time-stamp/update-receive-time-stamp.component';
import { UpdateSaleTimeStampComponent } from './update-sale-time-stamp/update-sale-time-stamp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { FormsModule } from '@angular/forms';
import { HttpClientServiceService } from './services/http-client-service.service';
import { HttpClientModule } from '@angular/common/http';
import { SearchComponent } from './search/search.component';

@NgModule({
  declarations: [
    AppComponent,
    AddRetailersComponent,
    ListRetailersComponent,
    UpdateReceiveTimeStampComponent,
    UpdateSaleTimeStampComponent,
    HeaderComponent,
    FooterComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClientServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
