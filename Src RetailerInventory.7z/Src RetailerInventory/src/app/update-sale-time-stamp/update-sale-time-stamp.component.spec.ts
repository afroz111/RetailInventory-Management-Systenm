import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateSaleTimeStampComponent } from './update-sale-time-stamp.component';

describe('UpdateSaleTimeStampComponent', () => {
  let component: UpdateSaleTimeStampComponent;
  let fixture: ComponentFixture<UpdateSaleTimeStampComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateSaleTimeStampComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateSaleTimeStampComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
