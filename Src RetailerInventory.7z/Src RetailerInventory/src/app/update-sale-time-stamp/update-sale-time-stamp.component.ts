import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientServiceService, Retailer } from '../services/http-client-service.service';

@Component({
  selector: 'app-update-sale-time-stamp',
  templateUrl: './update-sale-time-stamp.component.html',
  styleUrls: ['./update-sale-time-stamp.component.css']
})
export class UpdateSaleTimeStampComponent implements OnInit {
  Date=new Date().toLocaleDateString
  
  retailer: Retailer =new Retailer("","","","",new(Date),new(Date),new(Date))
  constructor(
    private HttpClientService:HttpClientServiceService,private router:Router
  ) { }

  ngOnInit(): void {
  }
  updateSaleTime(): void {
    console.log(this.retailer.productSaleTimestamp);
    this.HttpClientService.updateSaleTime(this.retailer)
        .subscribe( data => {
          alert("SaleTime  updated successfully.");
        });
        this.router.navigate(['/list-retailers']);
};
}
