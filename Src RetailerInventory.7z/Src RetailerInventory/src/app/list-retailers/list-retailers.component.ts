import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientServiceService, Retailer } from '../services/http-client-service.service';

@Component({
  selector: 'app-list-retailers',
  templateUrl: './list-retailers.component.html',
  styleUrls: ['./list-retailers.component.css']
})
export class ListRetailersComponent implements OnInit {
retailers:Retailer[];
  constructor(
    private httpClientService:HttpClientServiceService,private router:Router
  ) { }

  ngOnInit(): void {
    this.httpClientService.ViewAll().subscribe(
    response =>{this.retailers=response
      console.log(JSON.stringify(this.retailers));
      });
  }
  deleteRetailer(retailer: Retailer): void {
    this.httpClientService.deleteRetailer(retailer)
      .subscribe( data => {
        alert("Are u Sure for Delete");
        this.retailers = this.retailers.filter(u => u !== retailer);
        alert("Delete Sucessfully..!!!");
      })
  };
}
