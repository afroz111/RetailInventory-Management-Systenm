import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientServiceService, Retailer } from '../services/http-client-service.service';

@Component({
  selector: 'app-add-retailers',
  templateUrl: './add-retailers.component.html',
  styleUrls: ['./add-retailers.component.css']
})
export class AddRetailersComponent implements OnInit {
  Date=new Date().toLocaleDateString
  
 retailer: Retailer =new Retailer("","","","",new(Date),new(Date),new(Date))
  constructor(
    private HttpClientService:HttpClientServiceService,private router:Router
  ) { }

  ngOnInit(): void {
  }
AddRetailer(): void{
  this.HttpClientService.AddRetailer(this.retailer).
  subscribe( data =>{
    alert("Retailer Added Sucessfully... ");
  });


  
};
}
