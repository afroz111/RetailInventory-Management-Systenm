import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRetailersComponent } from './add-retailers.component';

describe('AddRetailersComponent', () => {
  let component: AddRetailersComponent;
  let fixture: ComponentFixture<AddRetailersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddRetailersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddRetailersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
